from flask import Flask, request, render_template_string, jsonify, Response
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import threading
import time
import csv
import io
from werkzeug.exceptions import RequestEntityTooLarge

# ------------------ Configuration ------------------ #
app = Flask(__name__)
# Hard server-side request limit (Flask will reject larger requests)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB
# Application-level accepted upload size for dataset route
MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MB

# ------------------ Default Dataset (demo) ------------------ #
DEFAULT_DATASET = [
    # spam examples (label 1)
    ("Claim your $1,000 Gift Card", "Congratulations — you’ve been selected for a $1,000 gift card. Click to claim now at https://example.com/claim.", 1),
    ("Urgent: Account Verification Required", "We detected suspicious activity. Verify your account immediately to avoid suspension: https://example.com/verify", 1),
    ("Win Cash Now — Limited Time Offer", "Enter our sweepstakes for a chance to win cash. Provide your phone number to qualify.", 1),
    ("Free Antivirus Download Inside", "Protect your PC today with our free antivirus. Download the installer from the link below.", 1),
    ("You’ve Won a Vacation Package", "You are the lucky winner of an all-expenses-paid trip. Reply with your passport number to confirm.", 1),
    ("Get Paid for Simple Online Tasks", "Earn $200/day working from home. Sign up and start immediately — no experience required.", 1),
    ("Important: Tax Refund Available", "You are eligible for a tax refund. Click here and enter your bank details to receive payment.", 1),
    ("Final Notice: Overdue Payment", "Your account is past due. Pay now to avoid legal action — follow the payment link.", 1),
    ("Exclusive Crypto Investment Tip", "Invest in this new coin before it explodes. Send funds to the wallet address to get early access.", 1),
    ("Reset Your Password Now", "We received a request to reset your password. If this wasn’t you, click here to secure your account.", 1),

    # legitimate examples (label 0)
    ("Meeting Request — Project Alpha Monday 10 AM", "Hi team — can we meet Monday at 10 AM to review Project Alpha milestones? Please confirm availability.", 0),
    ("Weekly Status Update — Marketing Campaign", "Attached is this week’s status report: campaign metrics, next steps, and blockers. Let me know questions.", 0),
    ("Invoice 2026-045 for Web Design Services", "Hello — please find invoice 2026-045 for web design services attached. Payment due in 30 days. Thank you.", 0),
    ("Quick Question About the Report", "Can you clarify the revenue numbers on page 3? I want to ensure the final draft is accurate.", 0),
    ("Lunch Tomorrow?", "Are you free for lunch tomorrow at 12:30? I know a new place nearby.", 0),
    ("Onboarding Documents and Next Steps", "Welcome aboard — attached are onboarding forms and a schedule for your first week. Please complete by Friday.", 0),
    ("Reminder: Team Offsite This Friday", "Friendly reminder about the offsite on Friday. Meet at the lobby at 8:30 AM; agenda attached.", 0),
    ("Thank You for Your Help", "Thanks for your support on the presentation. Your edits made a big difference.", 0),
    ("Request for Access to Shared Drive", "Could you grant me access to the Marketing shared drive? I need the assets for tomorrow’s meeting.", 0),
    ("Customer Support Ticket Resolved", "Your ticket has been resolved. If you still experience issues, reply and we’ll reopen the case.", 0),
]

# ------------------ Model and training helpers ------------------ #
model_lock = threading.Lock()
vectorizer = TfidfVectorizer()
model = MultinomialNB()

def train_model_from_list(dataset):
    """Train vectorizer and model from dataset: list of (subject, body, label)."""
    texts = [(s or "") + " " + (b or "") for s, b, _ in dataset]
    labels = [int(l) for _, _, l in dataset]
    with model_lock:
        global vectorizer, model
        vectorizer = TfidfVectorizer()
        X = vectorizer.fit_transform(texts)
        model = MultinomialNB()
        model.fit(X, labels)

# initial training
train_model_from_list(DEFAULT_DATASET)

def predict_spam_with_confidence(subject, body):
    text = (subject or "") + " " + (body or "")
    with model_lock:
        vec = vectorizer.transform([text])
        probs = model.predict_proba(vec)[0]
        label = int(model.predict(vec)[0])
    confidence = float(probs[label])
    return label, confidence

# ------------------ In-memory history and stats ------------------ #
history_lock = threading.Lock()
history = []

def add_to_history(subject, body, label, confidence):
    with history_lock:
        history.insert(0, {
            "subject": subject,
            "body": body,
            "label": "Spam" if label == 1 else "Legitimate",
            "confidence": round(confidence * 100, 1),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        })
        if len(history) > 200:
            history.pop()

def compute_stats():
    with history_lock:
        total = len(history)
        spam_count = sum(1 for h in history if h["label"] == "Spam")
        legit_count = total - spam_count
        avg_conf = round((sum(h["confidence"] for h in history) / total) if total else 0, 1)
    return {"total": total, "spam": spam_count, "legit": legit_count, "avg_conf": avg_conf}

# ------------------ HTML Template (with larger upload limit reflected) ------------------ #
HTML = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Email Spam Detector</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body{font-family:Arial,Helvetica,sans-serif;background:#f6f7fb;margin:24px;color:#111}
    .wrap{max-width:1100px;margin:0 auto;display:flex;gap:24px;align-items:flex-start}
    .left{flex:1}.right{width:340px}
    .card{background:#fff;padding:18px;border-radius:10px;box-shadow:0 6px 18px rgba(20,20,50,0.06);margin-bottom:16px}
    .stats{display:flex;gap:12px;margin-bottom:12px;flex-wrap:wrap}
    .stat{padding:12px;border-radius:8px;min-width:140px}
    input,textarea{width:100%;padding:10px;border-radius:8px;border:1px solid #e6e9ef;box-sizing:border-box}
    .btn{background:linear-gradient(90deg,#6a3bd8,#8b5cf6);color:#fff;padding:10px 14px;border-radius:10px;border:none;cursor:pointer}
    .muted{color:#6b7280;font-size:13px}
    .small{font-size:13px;color:#6b7280}
    .history{max-height:420px;overflow:auto}
    .file-input{display:flex;gap:8px;align-items:center}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="left">
      <div class="card">
        <div style="display:flex;gap:12px;align-items:center;justify-content:space-between">
          <div>
            <div class="muted">Total Analyzed</div>
            <div id="stat-total" style="font-weight:700;font-size:20px">0</div>
          </div>
          <div>
            <div class="muted">Spam Detected</div>
            <div id="stat-spam" style="font-weight:700;font-size:20px">0</div>
          </div>
          <div>
            <div class="muted">Legitimate</div>
            <div id="stat-legit" style="font-weight:700;font-size:20px">0</div>
          </div>
          <div>
            <div class="muted">Avg Confidence</div>
            <div id="stat-avg" style="font-weight:700;font-size:20px">0%</div>
          </div>
        </div>
      </div>

      <div class="card">
        <h3 style="margin-top:0">Analyze Email</h3>
        <div style="margin-bottom:10px">
          <label class="small">Subject Line</label>
          <input id="subject" placeholder="Enter email subject…" />
        </div>
        <div style="margin-bottom:12px">
          <label class="small">Email Content</label>
          <textarea id="body" placeholder="Enter email content…"></textarea>
        </div>
        <div style="display:flex;gap:12px;align-items:center">
          <button id="analyze-btn" class="btn" onclick="analyzeEmail()">Analyze</button>
          <div id="last-result" class="small"></div>
        </div>
      </div>

      <div class="card">
        <h3 style="margin-top:0">Dataset</h3>
        <div style="display:flex;gap:8px;align-items:center;margin-bottom:10px">
          <a href="/download_dataset" class="btn" style="text-decoration:none;display:inline-block">Download Dataset (CSV)</a>
        </div>

        <div style="margin-top:8px">
          <div class="small" style="margin-bottom:6px">Upload CSV to retrain model (columns: subject,body,label). Max 10MB.</div>
          <form id="upload-form" onsubmit="return false;" class="file-input">
            <input id="dataset-file" type="file" accept=".csv" />
            <button class="btn" onclick="uploadDataset()">Upload</button>
          </form>
          <div id="upload-msg" class="small" style="margin-top:8px"></div>
        </div>
      </div>
    </div>

    <div class="right">
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <h3 style="margin:0">Detection History</h3>
          <button onclick="refreshStatsAndHistory()" style="background:#eef2ff;border:none;padding:8px;border-radius:8px;color:#6a3bd8;cursor:pointer">⟳</button>
        </div>
        <div id="history" class="history small" style="margin-top:12px">
          <div style="text-align:center;color:#6b7280;padding:18px">No emails analyzed yet</div>
        </div>
      </div>
    </div>
  </div>

<script>
async function refreshStatsAndHistory(){
  const res = await fetch('/stats');
  const data = await res.json();
  document.getElementById('stat-total').textContent = data.total;
  document.getElementById('stat-spam').textContent = data.spam;
  document.getElementById('stat-legit').textContent = data.legit;
  document.getElementById('stat-avg').textContent = data.avg_conf + '%';

  const histRes = await fetch('/history');
  const hist = await histRes.json();
  const container = document.getElementById('history');
  container.innerHTML = '';
  if(hist.length === 0){
    container.innerHTML = '<div style="text-align:center;color:#6b7280;padding:18px">No emails analyzed yet</div>';
    return;
  }
  hist.forEach(item => {
    const div = document.createElement('div');
    div.style.padding = '10px';
    div.style.borderBottom = '1px solid #f1f3f7';
    div.innerHTML = '<div style="display:flex;justify-content:space-between"><strong>' +
      (item.subject || '(no subject)') + '</strong><span style="color:#6b7280;font-size:12px">' + item.timestamp + '</span></div>' +
      '<div style="color:#6b7280;margin-top:6px">' + (item.body || '').slice(0,120) + (item.body && item.body.length>120?'…':'') + '</div>' +
      '<div style="margin-top:8px"><span style="padding:6px 10px;border-radius:999px;color:#fff;background:' + (item.label==='Spam'?'#ef4444':'#10b981') + ';font-weight:700">' + item.label + '</span>' +
      '<span style="margin-left:8px;color:#6b7280">Confidence: ' + item.confidence + '%</span></div>';
    container.appendChild(div);
  });
}

async function analyzeEmail(){
  const btn = document.getElementById('analyze-btn');
  const subject = document.getElementById('subject').value;
  const body = document.getElementById('body').value;
  btn.disabled = true;
  btn.textContent = 'Analyzing…';
  try {
    const res = await fetch('/analyze', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({subject, body})
    });
    const data = await res.json();
    document.getElementById('last-result').innerHTML = 'Result: <strong>' + data.label + '</strong> (' + data.confidence + '%)';
    await refreshStatsAndHistory();
  } catch(e){
    alert('Error analyzing email');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Analyze';
  }
}

async function uploadDataset(){
  const fileInput = document.getElementById('dataset-file');
  const msg = document.getElementById('upload-msg');
  if(!fileInput.files.length){
    msg.textContent = 'Please choose a CSV file first.';
    return;
  }
  const file = fileInput.files[0];
  // client-side size check matches server-side MAX_UPLOAD_BYTES (10MB)
  if(file.size > 10 * 1024 * 1024){
    msg.textContent = 'File too large (max 10MB).';
    return;
  }
  msg.textContent = 'Uploading and retraining…';
  const form = new FormData();
  form.append('file', file);
  try {
    const res = await fetch('/upload_dataset', {method:'POST', body: form});
    const data = await res.json();
    if(data.success){
      msg.textContent = 'Model retrained on uploaded dataset. ' + data.count + ' rows used.';
      await refreshStatsAndHistory();
    } else {
      msg.textContent = 'Upload failed: ' + data.error;
    }
  } catch(e){
    msg.textContent = 'Upload error';
  }
}

refreshStatsAndHistory();
</script>
</body>
</html>
"""

# ------------------ Flask Routes ------------------ #
@app.errorhandler(RequestEntityTooLarge)
def handle_file_too_large(e):
    return jsonify({"success": False, "error": "Request too large (exceeds server limit)."}), 413

@app.route('/')
def index():
    return render_template_string(HTML)

@app.route('/analyze', methods=['POST'])
def analyze():
    payload = request.get_json() or {}
    subject = (payload.get('subject') or "")[:2000]
    body = (payload.get('body') or "")[:10000]
    label, confidence = predict_spam_with_confidence(subject, body)
    add_to_history(subject, body, label, confidence)
    return jsonify({
        "label": "Spam" if label == 1 else "Legitimate",
        "confidence": round(confidence * 100, 1)
    })

@app.route('/history', methods=['GET'])
def get_history():
    with history_lock:
        return jsonify(history)

@app.route('/stats', methods=['GET'])
def stats():
    s = compute_stats()
    return jsonify({
        "total": s["total"],
        "spam": s["spam"],
        "legit": s["legit"],
        "avg_conf": s["avg_conf"]
    })

@app.route('/download_dataset', methods=['GET'])
def download_dataset():
    """Return the default dataset as CSV for the user to download."""
    si = io.StringIO()
    writer = csv.writer(si)
    writer.writerow(["subject", "body", "label"])  # header
    for subject, body, label in DEFAULT_DATASET:
        writer.writerow([subject, body, label])
    output = si.getvalue()
    return Response(output, mimetype="text/csv",
                    headers={"Content-Disposition":"attachment;filename=spam_dataset.csv"})

@app.route('/upload_dataset', methods=['POST'])
def upload_dataset():
    """
    Accept a CSV file with columns: subject, body, label
    label should be 0 or 1. Retrain model on uploaded data.
    """
    file = request.files.get('file')
    if not file:
        return jsonify({"success": False, "error": "No file uploaded"}), 400

    # server-side size check (use MAX_UPLOAD_BYTES)
    file.seek(0, io.SEEK_END)
    size = file.tell()
    file.seek(0)
    if size > MAX_UPLOAD_BYTES:
        return jsonify({"success": False, "error": f"File too large (max {MAX_UPLOAD_BYTES // (1024*1024)}MB)"}), 400

    try:
        stream = io.StringIO(file.stream.read().decode('utf-8', errors='replace'))
        reader = csv.DictReader(stream)
        rows = []
        for i, row in enumerate(reader):
            if i >= 20000:  # safety cap on rows processed
                break
            subj = (row.get('subject') or row.get('Subject') or "")[:2000]
            body = (row.get('body') or row.get('Body') or "")[:10000]
            lbl = row.get('label') or row.get('Label')
            if lbl is None:
                continue
            try:
                lbl_int = int(float(lbl))
                if lbl_int not in (0, 1):
                    continue
            except:
                continue
            rows.append((subj, body, lbl_int))
        if len(rows) < 10:
            return jsonify({"success": False, "error": "Not enough valid rows (need at least 10)."}), 400

        # retrain model in background thread to avoid blocking long requests
        def retrain_task(dataset_rows):
            train_model_from_list(dataset_rows)
            # clear history after retrain to avoid mixing old stats with new model
            with history_lock:
                history.clear()

        threading.Thread(target=retrain_task, args=(rows,), daemon=True).start()
        return jsonify({"success": True, "count": len(rows)})
    except Exception:
        return jsonify({"success": False, "error": "Failed to parse CSV"}), 400

if __name__ == '__main__':
    app.run(debug=True)
